import { LoginPage } from "../Pages/Loginpage";
import { pageFixture } from "../hooks/pageFixture";
import { CredentialsOrangeHRM } from "../Files/TestData.json"
import { Given, } from "@cucumber/cucumber";
import { ForgotYourPasswordPage } from "../Pages/ForgotYourPasswordPage";


let lp: LoginPage
let fyp: ForgotYourPasswordPage

Given('I launch the OrangeHRM Application', async function () {

    lp = new LoginPage(pageFixture.page)

   await lp.navigateToOrangeHRM(CredentialsOrangeHRM.url)
})


Given('I verify Login functionality for the OrangeHRM Application', async function () {

    lp = new LoginPage(pageFixture.page)

    await lp.enterCredentials(CredentialsOrangeHRM.username, CredentialsOrangeHRM.password)
})

Given('I verify Login forgot Your Password functionality for the OrangeHRM Application', async function () {

    lp = new LoginPage(pageFixture.page)
    await lp.clickForgotYourPasswordLink()
    
    fyp =new ForgotYourPasswordPage(pageFixture.page)
    await fyp.enterUsername(CredentialsOrangeHRM.usernameFYP)
    await fyp.clickCancelButton()
    
    await pageFixture.page.waitForTimeout(5000);

})